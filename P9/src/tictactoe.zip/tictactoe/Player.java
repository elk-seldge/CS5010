package tictactoe;

/**
 * Represents a player in a Tic Tac Toe game.
 */
public enum Player {
  X,
  O,
}
